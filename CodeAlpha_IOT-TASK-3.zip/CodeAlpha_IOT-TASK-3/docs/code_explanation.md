# Code Explanation
## CodeAlpha IoT Task — Arduino Sketch Deep Dive

---

## Overview

The sketch reads three sensors every 500 ms, applies threshold logic to drive three LEDs, and streams readings to the Serial Monitor at 9600 baud. All logic lives in a single `.ino` file for simplicity and portability.

---

## Section 1 — Pin Definitions

```cpp
const int TEMP_PIN = A0;   // TMP36 analog temperature sensor
const int LDR_PIN  = A1;   // LDR analog light sensor
const int PIR_PIN  = 2;    // PIR digital motion sensor
const int LED_TEMP = 9;    // Red LED
const int LED_LDR  = 10;   // Blue LED
const int LED_PIR  = 11;   // Yellow LED
```

Six named constants replace raw pin numbers throughout the code. This makes the sketch readable and allows pin reassignment in one place without hunting through the loop body.

---

## Section 2 — Threshold Constants

```cpp
const float TEMP_THRESHOLD = 30.0;   // °C
const int   LDR_THRESHOLD  = 300;    // ADC units
```

| Constant | Value | Meaning |
|---|---|---|
| `TEMP_THRESHOLD` | 30.0 °C | Red LED activates above this (heat alert) |
| `LDR_THRESHOLD` | 300 ADC | Blue LED activates below this (dark room) |

Both constants are easily adjusted for different deployment environments.

---

## Section 3 — setup() Function

```cpp
void setup() {
  Serial.begin(9600);
  pinMode(PIR_PIN,  INPUT);
  pinMode(LED_TEMP, OUTPUT);
  pinMode(LED_LDR,  OUTPUT);
  pinMode(LED_PIR,  OUTPUT);
  Serial.println("IoT System Initialized.");
}
```

Runs **once** on power-on or reset. `Serial.begin(9600)` opens the UART channel at 9600 bits/second. `pinMode()` configures each GPIO as either INPUT (sensors) or OUTPUT (LEDs). A startup message confirms the system booted correctly.

---

## Section 4 — Temperature Reading (TMP36)

```cpp
int   rawADC  = analogRead(TEMP_PIN);        // 0–1023
float voltage = rawADC * (5.0 / 1023.0);    // → Volts
float tempC   = (voltage - 0.5) * 100.0;    // → Celsius
```

**ADC conversion chain:**

```
Raw ADC (0–1023)
    × (5.0 / 1023.0)
    = Voltage (0–5V)
    − 0.5 V (TMP36 offset)
    × 100
    = Temperature in °C
```

| ADC Value | Voltage | Temperature |
|---|---|---|
| 0 | 0.00 V | −50°C |
| 563 | 2.75 V | 22.5°C (room temp) |
| 665 | 3.25 V | 27.5°C |
| 737 | 3.60 V | 31.0°C → **Red LED ON** |
| 1023 | 5.00 V | 150°C |

---

## Section 5 — Light Sensing (LDR Voltage Divider)

```cpp
int ldrValue = analogRead(LDR_PIN);
```

The LDR and 10kΩ resistor form a **voltage divider**:

```
5V ──[LDR]──┬──[10kΩ]── GND
             └── A1 (ADC reading)
```

| Condition | LDR Resistance | A1 Voltage | ADC Value | Blue LED |
|---|---|---|---|---|
| Bright daylight | ~1kΩ | ~4.5V | ~920 | OFF |
| Indoor light | ~10kΩ | 2.5V | ~512 | OFF |
| Dark room | ~100kΩ | ~0.45V | ~92 | **ON** |

When `ldrValue < 300`, it's considered dark and the Blue LED on D10 activates, simulating automatic night lighting.

---

## Section 6 — Motion Detection (PIR HC-SR501)

```cpp
int motionDetected = digitalRead(PIR_PIN);
```

The PIR sensor emits a digital HIGH pulse when it detects infrared radiation from a moving warm body (person, animal).

| `digitalRead` | State | Yellow LED |
|---|---|---|
| `HIGH` (1) | Motion present | **ON** |
| `LOW` (0) | No motion | OFF |

The PIR has a built-in configurable **hold-time** (via onboard potentiometer) before automatically returning to LOW. No debouncing is needed in firmware.

---

## Section 7 — LED Control Logic

```cpp
digitalWrite(LED_TEMP, tempC          > TEMP_THRESHOLD ? HIGH : LOW);
digitalWrite(LED_LDR,  ldrValue       < LDR_THRESHOLD  ? HIGH : LOW);
digitalWrite(LED_PIR,  motionDetected == HIGH           ? HIGH : LOW);
```

Each line uses a **ternary operator** — a compact if/else that evaluates the condition and writes HIGH or LOW to the LED pin in a single expression. This is both concise and efficient.

---

## Section 8 — Serial Monitor Output

```cpp
Serial.print("Temp: ");   Serial.print(tempC, 1);
Serial.print("C | LDR: "); Serial.print(ldrValue);
Serial.print(" | Motion: "); Serial.println(motionDetected ? "YES" : "NO");
delay(500);
```

Every 500 ms a formatted line is printed to the Serial Monitor:

```
[2s] Temp: 31.4C | LDR: 570 | Motion: NO  << HEAT ALERT (D9 HIGH)
[3s] Temp: 31.4C | LDR: 570 | Motion: YES << MOTION DETECTED (D11 HIGH)
```

`delay(500)` pauses the loop for half a second before the next sensor cycle. This keeps the serial output readable and reduces ADC noise from rapid sampling.

---

## Complete Logic Truth Table

| Condition | Sensor Reading | LED | State |
|---|---|---|---|
| Temp > 30°C | ADC > 737 | Red (D9) | ON |
| Temp ≤ 30°C | ADC ≤ 737 | Red (D9) | OFF |
| LDR ADC < 300 (dark) | Low voltage | Blue (D10) | ON |
| LDR ADC ≥ 300 (light) | High voltage | Blue (D10) | OFF |
| PIR = HIGH (motion) | Digital 1 | Yellow (D11) | ON |
| PIR = LOW (no motion) | Digital 0 | Yellow (D11) | OFF |
