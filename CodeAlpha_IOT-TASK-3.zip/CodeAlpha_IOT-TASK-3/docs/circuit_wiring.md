# Circuit Wiring Guide
## CodeAlpha IoT Task — Arduino UNO Sensor LED System

---

## ASCII Schematic

```
                    ARDUINO UNO
                 +-------------------+
[TMP36]  ──────► | A0            D9  |──► 220Ω ──► [RED LED] ──► GND
[LDR+10k]──────► | A1            D10 |──► 220Ω ──► [BLUE LED] ──► GND
[PIR]    ──────► | D2            D11 |──► 220Ω ──► [YELLOW LED] ──► GND
[5V Rail]──────► | 5V            GND |──► Common Ground Rail
                 +-------------------+
```

---

## Pin Connection Table

| Component      | Arduino Pin | Type       | Series Resistor | Function                     |
|----------------|-------------|------------|-----------------|------------------------------|
| TMP36 Sensor   | A0          | Analog IN  | None            | Temperature voltage (0–5V)   |
| LDR + 10kΩ     | A1          | Analog IN  | 10kΩ pulldown   | Light level ADC (0–1023)     |
| PIR HC-SR501   | D2          | Digital IN | None            | Motion: HIGH / LOW           |
| Red LED        | D9          | Digital OUT| 220Ω            | Temperature alert            |
| Blue LED       | D10         | Digital OUT| 220Ω            | Darkness / night indicator   |
| Yellow LED     | D11         | Digital OUT| 220Ω            | Motion alert                 |

---

## Sensor Wiring Detail

### TMP36 Temperature Sensor
```
TMP36 Pin 1  (VCC)  ──► Arduino 5V
TMP36 Pin 2  (VOUT) ──► Arduino A0
TMP36 Pin 3  (GND)  ──► Arduino GND

Formula: Temp(°C) = (VOUT_mV - 500) / 10
Example: 750 mV → (750 - 500) / 10 = 25°C
```

### LDR Light Sensor (Voltage Divider)
```
5V ──► [LDR] ──► (midpoint = A1) ──► [10kΩ] ──► GND

Bright Light: LDR resistance ↓ → A1 voltage ↑ → ADC HIGH (bright)
Dark Room:    LDR resistance ↑ → A1 voltage ↓ → ADC LOW  (dark)
Threshold:    ADC < 300 = DARK → Blue LED ON
```

### PIR HC-SR501 Motion Sensor
```
PIR Pin 1 (VCC) ──► Arduino 5V
PIR Pin 2 (OUT) ──► Arduino D2
PIR Pin 3 (GND) ──► Arduino GND

D2 = HIGH → Motion detected → Yellow LED ON
D2 = LOW  → No motion       → Yellow LED OFF
```

### LED Wiring (all three identical pattern)
```
Arduino Pin (D9/D10/D11)
      │
    [220Ω]         ← current-limiting resistor (prevents LED burnout)
      │
   [LED Anode +]
   [LED Cathode -]
      │
     GND
```

---

## Extended Circuit (sketch_extended.ino)

| Additional Component | Arduino Pin | Type        | Series Resistor | Function            |
|----------------------|-------------|-------------|-----------------|---------------------|
| Orange LED           | D6          | Digital OUT | 220Ω            | Warning temp (35°C) |
| White LED            | D7          | Digital OUT | 220Ω            | Critical temp (40°C)|
| Piezo Buzzer         | D8          | Digital OUT | None            | Audible heat alert  |

---

## Tinkercad Setup Steps

1. Open [tinkercad.com](https://www.tinkercad.com) → Circuits → Create new Circuit
2. Drag **Arduino UNO** onto workspace
3. Add **TMP36**: VCC→5V, GND→GND, VOUT→A0
4. Add **LDR** + **10kΩ resistor** in voltage divider: midpoint→A1, resistor→GND, LDR→5V
5. Add **PIR HC-SR501**: VCC→5V, GND→GND, OUT→D2
6. Place **Red LED** + 220Ω: anode (through resistor)→D9, cathode→GND
7. Place **Blue LED** + 220Ω: D10; **Yellow LED** + 220Ω: D11; all cathodes→GND
8. Click **Code** toolbar → **Text mode** → paste `src/sketch.ino`
9. Click **Start Simulation** → open **Serial Monitor** tab
10. Drag TMP36 slider above 30°C → Red LED turns ON
11. Set LDR value below 300 → Blue LED turns ON
12. Click PIR and trigger motion → Yellow LED turns ON
