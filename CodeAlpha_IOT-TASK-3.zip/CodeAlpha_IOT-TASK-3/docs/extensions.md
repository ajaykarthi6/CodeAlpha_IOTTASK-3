# Extensions & Future Work
## CodeAlpha IoT Task — Possible Enhancements

---

## Built-in Extensions (Implemented in `sketch_extended.ino`)

### 1. Multi-Level Temperature Thresholds
Three alert levels replace the single threshold:

| Level | Threshold | LED | Buzzer |
|---|---|---|---|
| Normal | < 30°C | Red OFF | Silent |
| Alert | ≥ 30°C | Red ON | Silent |
| Warning | ≥ 35°C | Red + Orange ON | Slow beep |
| Critical | ≥ 40°C | Red + Orange + White ON | Fast beep |

### 2. Piezo Buzzer Alert
```cpp
const int BUZZER_PIN = 8;
void beepSlow() { tone(BUZZER_PIN, 1000, 200); delay(600); }
void beepFast() { tone(BUZZER_PIN, 2000, 100); delay(200); }
```
Connect a passive piezo buzzer between D8 and GND.

---

## Planned Extensions

### 3. LCD Display
Display live sensor readings on a 16×2 LCD (I2C):
```cpp
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  lcd.init();
  lcd.backlight();
}

void loop() {
  lcd.setCursor(0, 0);
  lcd.print("T:"); lcd.print(tempC, 1); lcd.print("C");
  lcd.setCursor(0, 1);
  lcd.print("L:"); lcd.print(ldrValue);
  lcd.print(" M:"); lcd.print(motionDetected ? "Y" : "N");
}
```
Wire: SDA→A4, SCL→A5 (Arduino UNO I2C pins).

---

### 4. Fan / Relay Control
Replace the LED with a relay module to drive a real DC fan:
```cpp
const int RELAY_PIN = 8;

// In loop():
digitalWrite(RELAY_PIN, tempC > TEMP_THRESHOLD ? HIGH : LOW);
// HIGH energizes the relay → fan turns ON
```

---

### 5. Wi-Fi IoT Upload (ESP8266 / ESP32)
Replace the Arduino UNO with an ESP8266 or ESP32 to push data to the cloud:
```cpp
#include <WiFi.h>
#include <HTTPClient.h>

const char* ssid     = "YOUR_SSID";
const char* password = "YOUR_PASS";
const char* endpoint = "https://api.your-iot-platform.com/data";

void sendData(float temp, int ldr, bool motion) {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(endpoint);
    http.addHeader("Content-Type", "application/json");
    String payload = "{\"temp\":" + String(temp) +
                     ",\"ldr\":"  + String(ldr)  +
                     ",\"motion\":" + String(motion) + "}";
    http.POST(payload);
    http.end();
  }
}
```
Compatible cloud platforms: ThingSpeak, Adafruit IO, MQTT broker, Firebase.

---

### 6. OLED Display (128×64)
```cpp
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 display(128, 64, &Wire, -1);

void showOLED(float temp, int ldr, bool motion) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Temp: "); display.print(temp); display.println(" C");
  display.print("LDR:  "); display.println(ldr);
  display.print("Motion: "); display.println(motion ? "YES" : "NO");
  display.display();
}
```

---

### 7. Data Logging to SD Card
```cpp
#include <SD.h>
File logFile;

void logToSD(float temp, int ldr, bool motion) {
  logFile = SD.open("log.csv", FILE_WRITE);
  if (logFile) {
    logFile.print(millis()); logFile.print(",");
    logFile.print(temp);     logFile.print(",");
    logFile.print(ldr);      logFile.print(",");
    logFile.println(motion ? 1 : 0);
    logFile.close();
  }
}
```
Wire SD module: CS→D4, MOSI→D11, MISO→D12, SCK→D13.

---

## Hardware Migration Checklist

When deploying from Tinkercad simulation to physical hardware:

- [ ] Upload sketch via `Tools → Port → [COM/ttyUSB]` in Arduino IDE
- [ ] Verify TMP36 orientation (flat face forward: VCC, VOUT, GND left to right)
- [ ] Add 100nF decoupling capacitor across PIR VCC–GND pins
- [ ] Use shielded wire for LDR to avoid EMI on long runs
- [ ] Test with Serial Monitor at 9600 baud before closing enclosure
- [ ] Adjust `TEMP_THRESHOLD` and `LDR_THRESHOLD` for real-world calibration
