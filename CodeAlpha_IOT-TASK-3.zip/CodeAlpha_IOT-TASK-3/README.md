# 🌐 CodeAlpha IoT Task — Sensor-Based LED Control System

> **Arduino UNO × TMP36 × LDR × PIR HC-SR501 — Simulated in Tinkercad / Proteus**

![Platform](https://img.shields.io/badge/Platform-Tinkercad%20%2F%20Proteus-blue)
![MCU](https://img.shields.io/badge/MCU-Arduino%20UNO%20ATmega328P-00979D?logo=arduino)
![Language](https://img.shields.io/badge/Language-Arduino%20C%2B%2B-00979D)
![Sensors](https://img.shields.io/badge/Sensors-TMP36%20%7C%20LDR%20%7C%20PIR-green)
![No Hardware](https://img.shields.io/badge/Hardware-Not%20Required-orange)
![License](https://img.shields.io/badge/License-MIT-lightgrey)

---

## 📌 Project Summary

| Field | Detail |
|---|---|
| **Platform** | Tinkercad (online) / Proteus (desktop) |
| **Microcontroller** | Arduino UNO (ATmega328P, 5V, 16MHz) |
| **Sensors** | TMP36 (Temperature) + LDR (Light) + PIR HC-SR501 (Motion) |
| **Actuators** | 3× LEDs — Red, Blue, Yellow — with 220Ω resistors |
| **Language** | Arduino C++ (compiled with avr-gcc) |
| **Serial Baud** | 9600 baud — readings every 500 ms |
| **No Hardware** | ✅ Fully simulated — no physical components required |

---

## 🎯 What This Project Does

This IoT simulation implements three fundamental sensor-actuator patterns on a single Arduino UNO:

| Pattern | Sensor | LED | Trigger |
|---|---|---|---|
| 🌡️ **Threshold Alert** | TMP36 Temperature | 🔴 Red | Temp > 30°C |
| 💡 **Adaptive Automation** | LDR Light | 🔵 Blue | LDR ADC < 300 (dark) |
| 🚶 **Event-Driven Response** | PIR Motion | 🟡 Yellow | Motion detected (HIGH) |

All sensor values are broadcast via **Serial Monitor at 9600 baud** for real-time monitoring.

---

## 📁 Repository Structure

```
CodeAlpha_IOT-TASK-3/
│
├── src/
│   ├── sketch.ino              ← Main Arduino sketch (core system)
│   └── sketch_extended.ino     ← Extended: multi-threshold + buzzer
│
├── docs/
│   ├── circuit_wiring.md       ← Full wiring guide + ASCII schematic
│   ├── code_explanation.md     ← Section-by-section code walkthrough
│   └── extensions.md           ← Future extensions (LCD, Wi-Fi, relay)
│
├── tools/
│   ├── serial_monitor.py       ← Python: read serial port + log to CSV
│   └── visualize_data.py       ← Python: plot sensor data from CSV
│
├── assets/
│   └── simulation_output/
│       └── sample_serial_log.txt  ← Example serial monitor session
│
├── .gitignore
└── README.md                   ← You are here
```

---

## ⚡ Circuit Diagram

```
                    ARDUINO UNO
                 +-------------------+
[TMP36]  ──────► | A0            D9  |──► 220Ω ──► [🔴 RED LED]    ──► GND
[LDR+10k]──────► | A1            D10 |──► 220Ω ──► [🔵 BLUE LED]   ──► GND
[PIR]    ──────► | D2            D11 |──► 220Ω ──► [🟡 YELLOW LED] ──► GND
[5V]     ──────► | 5V            GND |──► Common Ground Rail
                 +-------------------+

TMP36  : VCC=5V, GND=GND, VOUT=A0  │  Formula: Temp°C = (Vout_mV − 500) / 10
LDR    : 5V──[LDR]──A1──[10kΩ]──GND (voltage divider)
PIR    : VCC=5V, GND=GND, OUT=D2   │  HIGH = motion detected
```

### Pin Reference Table

| Component | Arduino Pin | Type | Resistor | Function |
|---|---|---|---|---|
| TMP36 Sensor | A0 | Analog IN | None | Temperature 0–5V |
| LDR + 10kΩ | A1 | Analog IN | 10kΩ pulldown | Light ADC 0–1023 |
| PIR HC-SR501 | D2 | Digital IN | None | Motion HIGH/LOW |
| 🔴 Red LED | D9 | Digital OUT | 220Ω | Heat alert |
| 🔵 Blue LED | D10 | Digital OUT | 220Ω | Night/dark mode |
| 🟡 Yellow LED | D11 | Digital OUT | 220Ω | Motion alert |

---

## 🖥️ Arduino Sketch

```cpp
// ── Pin Definitions ──────────────────────────────────────────────
const int TEMP_PIN  = A0;  // TMP36 temperature sensor
const int LDR_PIN   = A1;  // LDR light sensor
const int PIR_PIN   = 2;   // PIR motion sensor
const int LED_TEMP  = 9;   // Red LED
const int LED_LDR   = 10;  // Blue LED
const int LED_PIR   = 11;  // Yellow LED

// ── Thresholds ───────────────────────────────────────────────────
const float TEMP_THRESHOLD = 30.0;  // °C
const int   LDR_THRESHOLD  = 300;   // ADC

void setup() {
  Serial.begin(9600);
  pinMode(PIR_PIN,  INPUT);
  pinMode(LED_TEMP, OUTPUT);
  pinMode(LED_LDR,  OUTPUT);
  pinMode(LED_PIR,  OUTPUT);
  Serial.println("IoT System Initialized. Sensors: TMP36 | LDR | PIR");
}

void loop() {
  // Read sensors
  int   rawADC       = analogRead(TEMP_PIN);
  float voltage      = rawADC * (5.0 / 1023.0);
  float tempC        = (voltage - 0.5) * 100.0;
  int   ldrValue     = analogRead(LDR_PIN);
  int   motionDetect = digitalRead(PIR_PIN);

  // Control LEDs
  digitalWrite(LED_TEMP, tempC          > TEMP_THRESHOLD ? HIGH : LOW);
  digitalWrite(LED_LDR,  ldrValue       < LDR_THRESHOLD  ? HIGH : LOW);
  digitalWrite(LED_PIR,  motionDetect  == HIGH            ? HIGH : LOW);

  // Serial output
  Serial.print("Temp: ");   Serial.print(tempC, 1);
  Serial.print("C | LDR: "); Serial.print(ldrValue);
  Serial.print(" | Motion: "); Serial.println(motionDetect ? "YES" : "NO");

  delay(500);
}
```

> 📄 Full annotated source: [`src/sketch.ino`](src/sketch.ino)  
> 🔧 Extended version (buzzer + multi-threshold): [`src/sketch_extended.ino`](src/sketch_extended.ino)

---

## 📊 Sensor Logic & Threshold Table

| Scenario | Sensor Value | LED | State | Meaning |
|---|---|---|---|---|
| Room temp = 24°C | ADC ~563 | 🔴 Red | **OFF** | Normal |
| Temp rises to 32°C | ADC ~737 | 🔴 Red | **ON** | Heat alert |
| Bright daylight | ADC ~800 | 🔵 Blue | **OFF** | Sufficient light |
| Dark room / night | ADC ~150 | 🔵 Blue | **ON** | Night mode |
| No movement | LOW (0) | 🟡 Yellow | **OFF** | Area clear |
| Person detected | HIGH (1) | 🟡 Yellow | **ON** | Motion alert |

---

## 📟 Sample Serial Monitor Output

```
==============================================
  CodeAlpha IoT Task — Sensor LED Controller
  Sensors : TMP36 | LDR | PIR HC-SR501
==============================================
[0s]  Temp: 24.3C | LDR: 620 | Motion: NO
[1s]  Temp: 25.1C | LDR: 580 | Motion: NO
[2s]  Temp: 31.4C | LDR: 570 | Motion: NO  << HEAT ALERT (D9 HIGH)
[3s]  Temp: 31.4C | LDR: 570 | Motion: YES << HEAT ALERT | MOTION DETECTED
[4s]  Temp: 31.4C | LDR: 250 | Motion: YES << HEAT ALERT | DARK MODE | MOTION
[5s]  Temp: 28.9C | LDR: 250 | Motion: NO  << DARK MODE (D10 HIGH)
[6s]  Temp: 22.0C | LDR: 890 | Motion: NO
```

> Full sample: [`assets/simulation_output/sample_serial_log.txt`](assets/simulation_output/sample_serial_log.txt)

---

## 🔬 Code Deep Dive

### TMP36 Conversion Formula
```
Raw ADC (0–1023)
  × (5.0 / 1023.0) = Voltage in Volts
  − 0.5            = Remove 500mV offset
  × 100            = Temperature in °C

Example: ADC 665 → 3.25V → (3.25 − 0.5) × 100 = 27.5°C
```

### LDR Voltage Divider
```
5V ──[LDR]──┬──[10kΩ]── GND
             └── A1

Bright: LDR resistance ↓ → voltage at A1 ↑ → ADC HIGH → Blue OFF
Dark:   LDR resistance ↑ → voltage at A1 ↓ → ADC LOW  → Blue ON
```

### PIR Digital Read
```cpp
int motionDetected = digitalRead(PIR_PIN);
// HIGH (1) = infrared radiation change = motion present
// LOW  (0) = no motion
```

> 📖 Full explanation: [`docs/code_explanation.md`](docs/code_explanation.md)

---

## 🚀 Running in Tinkercad

1. Go to [tinkercad.com](https://www.tinkercad.com) → **Circuits** → **Create new Circuit**
2. Drag an **Arduino UNO** onto the workspace
3. Wire **TMP36**: VCC→5V, GND→GND, VOUT→A0
4. Wire **LDR + 10kΩ** voltage divider: midpoint→A1
5. Wire **PIR HC-SR501**: VCC→5V, GND→GND, OUT→D2
6. Add **Red LED + 220Ω** → D9; **Blue + 220Ω** → D10; **Yellow + 220Ω** → D11
7. **Code** → **Text mode** → paste contents of `src/sketch.ino`
8. Click **Start Simulation** → open **Serial Monitor**
9. Drag TMP36 slider above 30°C → 🔴 Red LED ON
10. Set LDR value below 300 → 🔵 Blue LED ON
11. Click PIR → trigger motion → 🟡 Yellow LED ON

### Expected Behavior

| Action | Result |
|---|---|
| TMP36 above 30°C | 🔴 Red LED turns ON immediately |
| TMP36 below 30°C | 🔴 Red LED turns OFF |
| LDR < 300 (dark) | 🔵 Blue LED turns ON |
| LDR ≥ 300 (bright) | 🔵 Blue LED turns OFF |
| PIR triggered | 🟡 Yellow LED ON for hold duration |
| PIR hold expires | 🟡 Yellow LED turns OFF automatically |

---

## 🛠️ Python Tools

### Serial Monitor + Logger
```bash
pip install pyserial
python tools/serial_monitor.py --port COM3 --timeout 120
```
Reads live Arduino serial output and saves to `sensor_log.csv`.

### Data Visualizer
```bash
pip install pandas matplotlib
python tools/visualize_data.py --file sensor_log.csv
```
Plots temperature, light level, and motion events over time.

---

## 🔌 Possible Extensions

| Extension | Difficulty | How |
|---|---|---|
| 🔔 Buzzer alert | Easy | Piezo on D8; `tone()` when temp > 35°C |
| 📺 LCD display | Medium | 16×2 I2C LCD; SDA→A4, SCL→A5 |
| 💨 Fan/relay | Medium | Replace LED with relay module on D8 |
| 🌍 Wi-Fi upload | Advanced | Replace UNO with ESP8266/ESP32 |
| 📊 OLED dashboard | Medium | Adafruit SSD1306 128×64 I2C |
| 💾 SD card log | Medium | SD library; log CSV to microSD |
| 🎨 Multi-threshold | Easy | Already in `sketch_extended.ino` |

> 📖 Full implementation code: [`docs/extensions.md`](docs/extensions.md)

---

## 🧠 Key Learnings

| Concept | Implementation |
|---|---|
| Analog-to-Digital Conversion | TMP36: ADC → Voltage → Celsius |
| Voltage Divider Circuit | LDR + 10kΩ for light level measurement |
| Digital I/O Control | PIR HIGH/LOW → LED state directly |
| Threshold-Based Logic | Ternary operator `condition ? HIGH : LOW` |
| Serial Telemetry | 9600 baud real-time IoT monitoring |
| Simulation Fidelity | Tinkercad matches physical Arduino exactly |
| Sensor Diversity | Analog (A0, A1) + Digital (D2) in one sketch |

---

## 📋 Hardware Migration Checklist

When moving from simulation to physical hardware:
- [ ] Upload via Arduino IDE → Tools → Port
- [ ] Verify TMP36 orientation (flat face forward)
- [ ] Add 100nF decoupling capacitor across PIR VCC–GND
- [ ] Use shielded wire for LDR on long cable runs
- [ ] Calibrate `TEMP_THRESHOLD` and `LDR_THRESHOLD` in real environment
- [ ] Open Serial Monitor at 9600 baud to verify readings

---

## 📜 License

MIT License — free to use, modify, and distribute with attribution.

---

*CodeAlpha Internship — IoT Task | Tinkercad Simulation | Arduino UNO*
