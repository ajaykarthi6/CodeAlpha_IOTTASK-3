// ================================================================
// IoT Sensor LED Control — EXTENDED VERSION
// Includes: Buzzer Alert + Multi-level Temperature Thresholds
// Platform : Tinkercad / Proteus / Physical Arduino UNO
// ================================================================

// ── Pin Definitions ─────────────────────────────────────────────
const int TEMP_PIN   = A0;
const int LDR_PIN    = A1;
const int PIR_PIN    = 2;

const int LED_TEMP   = 9;     // Red   — heat alert
const int LED_LDR    = 10;    // Blue  — dark/night mode
const int LED_PIR    = 11;    // Yellow — motion alert
const int LED_WARN   = 6;     // Orange — warning level (NEW)
const int LED_CRIT   = 7;     // White  — critical level (NEW)
const int BUZZER_PIN = 8;     // Piezo buzzer (NEW)

// ── Threshold Constants ──────────────────────────────────────────
const float TEMP_NORMAL   = 30.0;   // °C — Red LED ON
const float TEMP_WARNING  = 35.0;   // °C — Orange LED + Slow Beep
const float TEMP_CRITICAL = 40.0;   // °C — White LED + Fast Beep
const int   LDR_THRESHOLD = 300;    // ADC — Blue LED ON below this

// ── setup() ─────────────────────────────────────────────────────
void setup() {
  Serial.begin(9600);
  pinMode(PIR_PIN,    INPUT);
  pinMode(LED_TEMP,   OUTPUT);
  pinMode(LED_LDR,    OUTPUT);
  pinMode(LED_PIR,    OUTPUT);
  pinMode(LED_WARN,   OUTPUT);
  pinMode(LED_CRIT,   OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  Serial.println("==============================================");
  Serial.println("  IoT Extended — Multi-Threshold + Buzzer");
  Serial.println("==============================================");
}

// ── Buzzer helpers ───────────────────────────────────────────────
void beepSlow() { tone(BUZZER_PIN, 1000, 200); delay(600); }
void beepFast() { tone(BUZZER_PIN, 2000, 100); delay(200); }

// ── loop() ──────────────────────────────────────────────────────
void loop() {

  // Read sensors
  int   rawADC       = analogRead(TEMP_PIN);
  float voltage      = rawADC * (5.0 / 1023.0);
  float tempC        = (voltage - 0.5) * 100.0;
  int   ldrValue     = analogRead(LDR_PIN);
  int   motionDetect = digitalRead(PIR_PIN);

  // ── Multi-level temperature logic ────────────────────────────
  if (tempC >= TEMP_CRITICAL) {
    digitalWrite(LED_TEMP, HIGH);
    digitalWrite(LED_WARN, HIGH);
    digitalWrite(LED_CRIT, HIGH);
    beepFast();
    Serial.println("[CRITICAL] Temp exceeds 40C!");
  } else if (tempC >= TEMP_WARNING) {
    digitalWrite(LED_TEMP, HIGH);
    digitalWrite(LED_WARN, HIGH);
    digitalWrite(LED_CRIT, LOW);
    beepSlow();
    Serial.println("[WARNING] Temp exceeds 35C!");
  } else if (tempC >= TEMP_NORMAL) {
    digitalWrite(LED_TEMP, HIGH);
    digitalWrite(LED_WARN, LOW);
    digitalWrite(LED_CRIT, LOW);
    noTone(BUZZER_PIN);
  } else {
    digitalWrite(LED_TEMP, LOW);
    digitalWrite(LED_WARN, LOW);
    digitalWrite(LED_CRIT, LOW);
    noTone(BUZZER_PIN);
  }

  // Light and motion
  digitalWrite(LED_LDR, ldrValue    < LDR_THRESHOLD ? HIGH : LOW);
  digitalWrite(LED_PIR, motionDetect == HIGH         ? HIGH : LOW);

  // Serial output
  Serial.print("["); Serial.print(millis()/1000); Serial.print("s] ");
  Serial.print("Temp: "); Serial.print(tempC, 1);
  Serial.print("C | LDR: "); Serial.print(ldrValue);
  Serial.print(" | Motion: "); Serial.println(motionDetect ? "YES" : "NO");

  delay(500);
}
