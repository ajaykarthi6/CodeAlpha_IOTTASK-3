#!/usr/bin/env python3
"""
=============================================================
  CodeAlpha IoT Task — Sensor Data Visualizer
  Reads sensor_log.csv and plots Temperature, LDR, Motion
  over time with LED state overlays
=============================================================
Requirements:
    pip install pandas matplotlib
Usage:
    python visualize_data.py --file sensor_log.csv
=============================================================
"""

import argparse
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

parser = argparse.ArgumentParser()
parser.add_argument("--file", default="sensor_log.csv")
args = parser.parse_args()

# ── Load data ────────────────────────────────────────────────────
df = pd.read_csv(args.file, parse_dates=["timestamp"])
df.set_index("timestamp", inplace=True)

fig, axes = plt.subplots(3, 1, figsize=(14, 9), sharex=True)
fig.suptitle("CodeAlpha IoT Task — Sensor Data Dashboard", fontsize=14, fontweight="bold")

# ── Plot 1: Temperature ──────────────────────────────────────────
ax1 = axes[0]
ax1.plot(df.index, df["temp_c"], color="#e74c3c", linewidth=1.8, label="Temperature (°C)")
ax1.axhline(30.0, color="#e74c3c", linestyle="--", alpha=0.5, label="Threshold (30°C)")
ax1.fill_between(df.index, df["temp_c"], 30, where=df["led_temp"], alpha=0.2, color="red", label="RED LED ON")
ax1.set_ylabel("Temperature (°C)")
ax1.legend(loc="upper right", fontsize=8)
ax1.grid(True, alpha=0.3)
ax1.set_title("🌡️  Temperature Sensor — TMP36 (A0)", fontsize=10)

# ── Plot 2: Light Level ──────────────────────────────────────────
ax2 = axes[1]
ax2.plot(df.index, df["ldr_adc"], color="#3498db", linewidth=1.8, label="LDR ADC Value")
ax2.axhline(300, color="#3498db", linestyle="--", alpha=0.5, label="Threshold (300 ADC)")
ax2.fill_between(df.index, df["ldr_adc"], 300, where=df["led_ldr"], alpha=0.2, color="blue", label="BLUE LED ON")
ax2.set_ylabel("LDR ADC (0–1023)")
ax2.legend(loc="upper right", fontsize=8)
ax2.grid(True, alpha=0.3)
ax2.set_title("💡  Light Sensor — LDR Voltage Divider (A1)", fontsize=10)

# ── Plot 3: Motion ───────────────────────────────────────────────
ax3 = axes[2]
ax3.fill_between(df.index, df["motion"].astype(int), alpha=0.6, color="#f39c12", label="Motion Detected")
ax3.set_yticks([0, 1])
ax3.set_yticklabels(["No Motion", "Motion!"])
ax3.set_ylabel("PIR State")
ax3.legend(loc="upper right", fontsize=8)
ax3.grid(True, alpha=0.3)
ax3.set_title("🚶  Motion Sensor — PIR HC-SR501 (D2)", fontsize=10)
ax3.set_xlabel("Timestamp")

plt.tight_layout()
plt.savefig("sensor_dashboard.png", dpi=150, bbox_inches="tight")
print("✅ Dashboard saved to sensor_dashboard.png")
plt.show()
