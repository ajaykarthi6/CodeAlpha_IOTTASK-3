#!/usr/bin/env python3
"""
=============================================================
  CodeAlpha IoT Task — Python Serial Monitor & Data Logger
  Reads live sensor data from Arduino via USB Serial port
  Logs to CSV with timestamps for analysis/graphing
=============================================================
Requirements:
    pip install pyserial
Usage:
    python serial_monitor.py --port COM3        (Windows)
    python serial_monitor.py --port /dev/ttyUSB0 (Linux/Mac)
=============================================================
"""

import serial
import csv
import time
import argparse
from datetime import datetime

# ── Config ──────────────────────────────────────────────────────
BAUD_RATE   = 9600
LOG_FILE    = "sensor_log.csv"
TEMP_THRESH = 30.0
LDR_THRESH  = 300

# ── Parse CLI args ───────────────────────────────────────────────
parser = argparse.ArgumentParser(description="Arduino IoT Serial Monitor")
parser.add_argument("--port", default="COM3", help="Serial port (e.g. COM3 or /dev/ttyUSB0)")
parser.add_argument("--timeout", type=int, default=60, help="Duration to log (seconds)")
args = parser.parse_args()

def parse_line(line: str) -> dict | None:
    """Parse a serial line like: '[5s] Temp: 31.4C | LDR: 570 | Motion: YES'"""
    try:
        line = line.strip()
        if "Temp:" not in line:
            return None
        temp_part   = line.split("Temp:")[1].split("C")[0].strip()
        ldr_part    = line.split("LDR:")[1].split("|")[0].strip()
        motion_part = line.split("Motion:")[1].split()[0].strip()
        return {
            "timestamp": datetime.now().isoformat(),
            "temp_c":    float(temp_part),
            "ldr_adc":   int(ldr_part),
            "motion":    motion_part.upper() == "YES",
            "led_temp":  float(temp_part) > TEMP_THRESH,
            "led_ldr":   int(ldr_part) < LDR_THRESH,
            "led_pir":   motion_part.upper() == "YES",
        }
    except Exception:
        return None

def run_monitor():
    print(f"Connecting to {args.port} at {BAUD_RATE} baud...")
    try:
        ser = serial.Serial(args.port, BAUD_RATE, timeout=1)
    except serial.SerialException as e:
        print(f"[ERROR] Could not open port: {e}")
        return

    print(f"Logging for {args.timeout}s → {LOG_FILE}")
    print("-" * 60)

    with open(LOG_FILE, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "timestamp","temp_c","ldr_adc","motion","led_temp","led_ldr","led_pir"
        ])
        writer.writeheader()

        start = time.time()
        while time.time() - start < args.timeout:
            raw = ser.readline().decode("utf-8", errors="ignore")
            if raw:
                data = parse_line(raw)
                if data:
                    print(
                        f"{data['timestamp']} | "
                        f"Temp: {data['temp_c']:.1f}°C | "
                        f"LDR: {data['ldr_adc']} | "
                        f"Motion: {'YES' if data['motion'] else 'NO'} | "
                        f"LEDs: {'R' if data['led_temp'] else '-'}"
                        f"{'B' if data['led_ldr'] else '-'}"
                        f"{'Y' if data['led_pir'] else '-'}"
                    )
                    writer.writerow(data)

    ser.close()
    print(f"\n✅ Done. Data saved to {LOG_FILE}")

if __name__ == "__main__":
    run_monitor()
